﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Coldairarrow.Api.Models
{
    public class DeviceDataModel
    {
        public string Device { get; set; }
    }
}
