﻿using Coldairarrow.Api.Hubs;
using Coldairarrow.Business.Base_Manage;
using Coldairarrow.Business.Device;
using Coldairarrow.Business.MeterReaDing;
using Coldairarrow.Entity.Device;
using Coldairarrow.Entity.MeterReaDing;
using Coldairarrow.Util;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Coldairarrow.Api.Timing
{
    public class CustomTime
    {
        ILogger logger { get; }
        IHubContext<RemoteHub> hubContext { get; }
        IMeterReaDingTimeSetUpBusiness timeSetUpBusiness { get; }
        IMeterReaDingOnDutyBusiness _meterReaDingOnDutyBus { get; }
        private IBase_DepartmentBusiness departmentBusiness { get; }
        private IDeviceDisplayModuleBusiness deviceDisplayModuleBusiness { get; }
        private List<MeterReaDingTimeSetUp> datas;

        public CustomTime(IHubContext<RemoteHub> hubContext,
            IMeterReaDingTimeSetUpBusiness timeSetUpBusiness, IMeterReaDingOnDutyBusiness meterReaDingOnDutyBus,
            ILogger logger, IBase_DepartmentBusiness departmentBusiness, IDeviceDisplayModuleBusiness deviceDisplayModuleBusiness)
        {
            this.hubContext = hubContext;
            this.timeSetUpBusiness = timeSetUpBusiness;
            this.logger = logger;
            _meterReaDingOnDutyBus = meterReaDingOnDutyBus;
            this.departmentBusiness = departmentBusiness;
            this.deviceDisplayModuleBusiness = deviceDisplayModuleBusiness;
        }

        public void Start()
        {
            this.datas = timeSetUpBusiness.GetList();
            new Thread(() =>
            {
                Thread.Sleep(1000);

                while (true)
                {
                    try
                    {
                        Thread.Sleep(1000);
                        TimeSpan startTime=new TimeSpan(0,0,0);
                        TimeSpan endTime = new TimeSpan(0, 0, 0);
                        var go = datas.FirstOrDefault(item =>
                        {
                            startTime = ToTimeSpan(item.MeterTime);
                            endTime = ToTimeSpan(item.MeterTime).Add(TimeSpan.FromMinutes(int.Parse(item.RangeTime)));
                            var currentTime = ToTimeSpan(DateTime.Now.ToString("HH:mm"));
                            if (currentTime >= startTime && currentTime < endTime)
                            {
                                return true;
                            }
                            return false;
                        });

                        if (go != null)
                        {
                            //时间范围内
                            hubContext.Clients.All.SendAsync("MeterReading", new { disabled = false, datetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") });
                            //程序抄表
                            MeterReading(go, startTime, endTime);
                        }
                        else
                        {
                            hubContext.Clients.All.SendAsync("MeterReading", new { disabled = true, datetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") });
                        }
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex);
                    }
                }
            }).Start();
        }

        public void UpdateData(List<MeterReaDingTimeSetUp> datas)
        {
            this.datas.Clear();
            this.datas.AddRange(datas);
        }

        private TimeSpan ToTimeSpan(string time)
        {
            var arr = time.Split(":");
            var span = new TimeSpan();

            if (arr.Length >= 1)
                span = span.Add(TimeSpan.FromHours(int.Parse(arr[0])));
            if (arr.Length >= 2)
                span = span.Add(TimeSpan.FromMinutes(int.Parse(arr[1])));
            if (arr.Length >= 3)
                span = span.Add(TimeSpan.FromSeconds(int.Parse(arr[2])));
            return span;
        }

        /// <summary>
        /// 抄表 
        /// </summary>
        /// <param name="go"></param>
        public void MeterReading(MeterReaDingTimeSetUp go, TimeSpan startTime, TimeSpan endTime)
        {
            var currentTime = ToTimeSpan(DateTime.Now.ToString("HH:mm"));
            if (currentTime == endTime)
            {
                //日期
                var startdata = Convert.ToDateTime(DateTime.Now.Date.ToString() + startTime);
                var enddata = Convert.ToDateTime(DateTime.Now.Date.ToString() + endTime);

                //部门
                //var data = departmentBusiness.GetList();
                //模块 设备
                var vdata = this.deviceDisplayModuleBusiness.GetVModeuleInfoList();
                var datas = CacheHelper.RedisCache.GetCache<List<T_DeviceData>>("DeviceData");

                var qMeter = from m in vdata
                             join b in datas on m.Departmentid equals b.DepartmentId
                             where (m.Deviceid == b.DeviceId && m.DeviceTypeId == b.DeviceTypeId && m.DevicePropId == b.DevicePropId)
                             select new
                             {
                                 Departmentid = m.Departmentid,
                                 DeviceDisplayModuleId = m.DeviceDisplayModuleId,
                                 moduleName = m.DeviceDisplayModuleName,
                                 DeviceName = m.DeviceName,
                                 propName = m.DevicePropName,
                                 propValue = b.Value

                             };

                var deptidlist = from f in vdata group f.Departmentid by f.Departmentid;

                foreach (var item in deptidlist)
                {
                    if (_meterReaDingOnDutyBus.GetMeterReaDingBydeptIdBystartTimeByendTime(item.Key.GetGetFieldValue("Departmentid").ToString(), startdata.ToString(), enddata.ToString()).Count == 0)
                    {
                        foreach (var list in qMeter.ToList())
                        {
                            MeterReaDingOnDuty datainfo = new MeterReaDingOnDuty();

                            datainfo.CreateTime = DateTime.Now;
                            datainfo.deptId = list.Departmentid;
                            datainfo.DeviceDisplayModuleID = list.DeviceDisplayModuleId;
                            datainfo.deviceName = list.DeviceName;
                            datainfo.moduleName = list.moduleName;
                            datainfo.propValue = list.propValue;
                            _meterReaDingOnDutyBus.AddData(datainfo);
                        } 
                    }
                }
                 
            }
        }
    }
}
